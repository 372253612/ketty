package com.ketty;

/**
 * AnyPaasServer
 * @author duanyy
 *
 */
public interface KettyServer{
	public void start(String args[]) throws Exception;
	public void join() throws Exception;
	public void stop() throws Exception;
}
