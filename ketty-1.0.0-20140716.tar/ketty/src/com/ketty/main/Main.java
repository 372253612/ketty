package com.ketty.main;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.ketty.KettyServer;

public class Main {
	public static void main(String[] args) {
		KettyServer server = new ConfigurableServer();
		Logger logger = LogManager.getLogger(Main.class);
		try {
			/**
			 * ConfigurableServer需要下列参数:
			 * - 下面是必选参数
			 *     + server.app | app
			 *         - 本服务器所对应的App代码
			 *         
			 * - 下面是可选参数、
			 *     + ketty.home | home 
			 *         - ketty的安装目录，为空时取操作系统的环境变量KETTY_HOME
			 *     + ketty.config
			 *         - 配置文件地址,缺省为java:///com/ketty/main/ketty.xml#com.ketty.main.Main
			 *     + ketty.config.ext
			 *         - 扩展配置文件地址,缺省无
			 *     + server.context | context
			 *         - Web Context的地址,缺省为${ketty.home}/webapps/ROOT
			 *     + server.port | port
			 *         - 对外服务所绑定的端口,当为空时,从8080-9080之间自动选择一个端口
			 *     + ketty.start
			 *         - 服务初始化脚本地址，缺省为java:///com/ketty/main/start.xml#com.ketty.main.Main
			 */

			/**
			 * 如:需要启动名为demo的服务器
			 * 
			 * System.setProperty("app", "demo");
			 * 
			 */
			server.start(args);
			server.join();
		}catch (Exception ex){
			logger.error(ex.getMessage());
		}
	}
}
