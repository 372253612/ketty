package com.ketty.main;

import java.io.File;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.util.Enumeration;
import java.util.concurrent.locks.Lock;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.xml.XmlConfiguration;

import com.anysoft.util.CommandLine;
import com.anysoft.util.IOTools;
import com.anysoft.util.PropertiesConstants;
import com.anysoft.util.Settings;
import com.anysoft.util.resource.ResourceFactory;
import com.ketty.KettyServer;
import com.ketty.util.LocalLock;

public class ConfigurableServer implements KettyServer {
	protected static Logger logger = LogManager.getLogger(ConfigurableServer.class);
	protected Server jettyServer = null;
	@Override
	public void start(String[] args) throws Exception {
		CommandLine cmd = new CommandLine(args);
		Settings settings = Settings.get();
		settings.addSettings(cmd);
		String kettyHome = settings.GetValue("home", "${ketty.home}");
		if (kettyHome == null || kettyHome.length() <= 0){
			kettyHome = System.getenv("KETTY_HOME");
			if (kettyHome == null || kettyHome.length() <= 0){
				throw new Exception("Can not find ketty home.Check parameter:ketty.home or home");
			}
		}
		settings.SetValue("ketty.home", kettyHome);
		
		ResourceFactory rf = new ResourceFactory();
		
		//首先,从命令行中读取anypaas.config变量,读取配置文件
		//缺省为java:///com.anypaas.main.settings.xml#com.anypaas.main.Main
		String configFile = settings.GetValue("ketty.config", 
				"java:///com/ketty/main/ketty.xml#com.ketty.main.Main");
		String configFileSecondary = settings.GetValue("ketty.config.secondary", 
				"java:///com/ketty/main/ketty.xml#com.ketty.main.Main");
		settings.addSettings(configFile, configFileSecondary, rf);
		logger.info("Add to settings,file:" + configFile);
		//还支持扩展的配置文件
		String extConfigFile = settings.GetValue("ketty.config.ext", "false");
		if (extConfigFile != null && !extConfigFile.equals("false")){
			settings.addSettings(extConfigFile, null, rf);
			logger.info("Add to settings,file:" + extConfigFile);
		}
		String contextPath = settings.GetValue("context", "${server.context}");
		if (contextPath == null || contextPath.length() <= 0){
			contextPath = kettyHome + File.separatorChar + "webapps" + File.separatorChar + "ROOT";
		}
		
		String port = settings.GetValue("port", "${server.port}");
		boolean portAuto = PropertiesConstants.getBoolean(settings,"port.auto",(port == null || port.length() <= 0),true);
		
		if (!portAuto){
			if (port == null || port.length() <= 0){
				throw new Exception("Can not find port.Check parameter:server.port or port.");
			}
			
			if (!isPortAvailable(port)){
				throw new Exception("The port is not available. port = " + port);
			}
		}
		
		String app = settings.GetValue("app", "${server.app}");
		if (app == null || app.length() <= 0){
			throw new Exception("Can not find app.Check parameter:app or server.app");
		}
		
		String jettyConfig = settings.GetValue("ketty.start", 
				"java:///com/ketty/main/start.xml#com.ketty.main.Main");
		String jettyConfigSecondary = settings.GetValue("ketty.start.secondary", 
				"java:///com/ketty/main/start.xml#com.ketty.main.Main");
		
		InputStream in = null;
		Lock lock = null;
		try {
			if (portAuto){
				lock = new LocalLock(settings.GetValue("lock", "${ketty.home}/locked"),settings);
				lock.lock();
				
				int _port = getAvailablePort(8080,9080);
				if (_port <= 0){
					throw new Exception("Can not find an available port between 8090 and 9080.");
				}
				port = String.valueOf(_port);
			}
			String ip = getHostIp();
			long mem = Runtime.getRuntime().maxMemory() / 1000 / 1000;
			long cores = Runtime.getRuntime().availableProcessors();
			
			System.setProperty("server.ip", ip);
			System.setProperty("server.port", port);
			System.setProperty("server.mem", String.valueOf(mem));
			System.setProperty("server.app", app);
			System.setProperty("server.cores", String.valueOf(cores));
			System.setProperty("server.context",contextPath);
			System.setProperty("ketty.home", kettyHome);
			
			PropertyConfigurator.configure(kettyHome + File.separatorChar + "conf" + File.separatorChar + "log4j.properties");
			
			in = rf.load(jettyConfig, jettyConfigSecondary, null);
			if (in == null){
				throw new Exception("Failed to load the start script:"+jettyConfig);
			}
			
			logger.info("Use xml configuration to start server");
			logger.info("URL = " + jettyConfig);
			XmlConfiguration xmlConfig = new XmlConfiguration(in);
			
			jettyServer = (Server)xmlConfig.configure();
			
	        jettyServer.start();
		} finally {
			IOTools.closeStream(in);
			if (lock != null){
				lock.unlock();
			}
		}			
	}

	@Override
	public void join() throws Exception {
		if (jettyServer != null){
			jettyServer.join();
		}
	}	
	
	@Override
	public void stop() throws Exception {
		if (jettyServer != null){
			jettyServer.stop();
		}
	}

	/**
	 * 判断指定端口是否可用
	 * 
	 * @param port 端口
	 * @return
	 */
	public static boolean isPortAvailable(String port){
		try {
			int _port = Integer.parseInt(port);
			ServerSocket socket = new ServerSocket(_port);
			socket.close();
			return true;
		}catch (Exception ex){
			logger.info("Port is binded , try another. port = " + port);
			return false;
		}
	}

	
	public static int getAvailablePort(int fromPort,int toPort){
		ServerSocket socket = null;
		for (int port = fromPort ; port < toPort ; port ++){
			try {
				socket = new ServerSocket(port);
				socket.close();
				logger.info("Port is available,port = " + port);
				return port;
			}catch (Exception ex){
				logger.info("Port is binded , try another. port = " + port);
				continue;
			}
		}
		return 0;
	}

	public static String getHostIp(){
		
		try {
			InetAddress addr = InetAddress.getLocalHost();
			return addr.getHostAddress();
		}catch (Exception ex){
			logger.error("Can not get ip from Local Host");
		}
		
		logger.info("Try to get ip from network interface.");
		Enumeration<NetworkInterface> interfaces = null;
		try {
			interfaces = NetworkInterface.getNetworkInterfaces();  
		}catch (Exception ex){
			return "127.0.0.1";
		}
        while (interfaces.hasMoreElements()) {  
            NetworkInterface ni = interfaces.nextElement();  
            Enumeration<InetAddress> addrs = ni.getInetAddresses();
            while (addrs.hasMoreElements()){
            	InetAddress inetAddr = addrs.nextElement();
            	
            	if (!inetAddr.getHostAddress().equalsIgnoreCase("127.0.0.1")){
            		return inetAddr.getHostAddress();
            	}
            }
        }
        return "127.0.0.1";
	}
	
	public static void main(String [] args){
		KettyServer server = new ConfigurableServer();
		try {
			/**
			 * ConfigurableServer需要下列参数:
			 * - 下面是必选参数
			 *     + server.app | app
			 *         - 本服务器所对应的App代码
			 *         
			 * - 下面是可选参数、
			 *     + ketty.home | home 
			 *         - ketty的安装目录，为空时取操作系统的环境变量KETTY_HOME
			 *     + ketty.config
			 *         - 配置文件地址,缺省为java:///com/ketty/main/ketty.xml#com.ketty.main.Main
			 *     + ketty.config.ext
			 *         - 扩展配置文件地址,缺省无
			 *     + server.context | context
			 *         - Web Context的地址,缺省为${ketty.home}/webapps/ROOT
			 *     + server.port | port
			 *         - 对外服务所绑定的端口,当为空时,从8080-9080之间自动选择一个端口
			 *     + ketty.start
			 *         - 服务初始化脚本地址，缺省为java:///com/ketty/main/start.xml#com.ketty.main.Main
			 */
			
			/**
			 * 如:需要启动名为demo的服务器
			 * 
			 * System.setProperty("app", "demo");
			 * 
			 */			
			server.start(args);
			server.join();
		}catch (Exception ex){
			logger.error(ex.getMessage());
		}
	}	
}
