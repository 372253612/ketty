package com.ketty;

import java.io.File;
import java.io.FilenameFilter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class Start {
	protected static Hashtable<String,String> cmds = new Hashtable<String,String>();
	
	protected static void parseCommandLine(String [] _cmd){
		for (int i = 0 ; i < _cmd.length ; i ++){
			String __cmd = _cmd[i];
			int __index = __cmd.indexOf("=");
			if (__index >= 0){
		         String __name = __cmd.substring(0,__index);
		         String __value = __cmd.substring(__index + 1,__cmd.length());
		         if (__name != null && __name.length() > 0){
		        	 if (__value != null && __value.length() > 0){
		        		 cmds.put(__name, __value);
		        	 }else{
		        		 cmds.put(__name, "true");
		        	 }
		         }
			}else{
				cmds.put(__cmd, "true");
			}
		}
	}
	
	protected static String get(String name,String dftValue){
		String value = cmds.get(name);
		if (value != null && value.length() > 0){
			return value;
		}
		
		value = System.getProperty(name);
		if (value != null && value.length() > 0){
			return value;
		}
		
		value = System.getenv(name);
		return value != null && value.length() > 0 ? value : dftValue;
	}

	protected static String gets(String defValue,String...keys){
		for (String key:keys){
			String value = get(key,"");
			if (value != null && value.length() > 0){
				return value;
			}
		}
		
		return defValue;
	}
	
	protected static void addLibary(List<URL> urls,String path){
		System.out.println("Searching jar libary in :" + path);
		File dir = new File(path);
		if (!dir.isDirectory()){
			return ;
		}
		
		File[] jars = dir.listFiles(new FilenameFilter() {
			@Override
			public boolean accept(File file, String name) {
				if (name.endsWith(".jar") || name.endsWith(".zip"))
					return true;
				return false;
			}
		});
		
		if (jars != null){
			for (File file:jars){
				try {
					urls.add(file.toURI().toURL());
					System.out.println("Add Jar:" + file.toString());
				} catch (MalformedURLException e) {
				}
			}
		}
	}
	
	public static void main(String[] args) {
		parseCommandLine(args);
		
		String app = get("app","");
		if (app == null || app.length() <= 0){
			System.out.println("Can not find app parameter.");
			return ;
		}

		String kettyHome = gets("","ketty.home","KETTY_HOME");
		if (kettyHome == null || kettyHome.length() <= 0){
			System.out.println("Can not find ketty home.");
			return ;
		}
		
		
		
		String context = gets("","context","server.context");
		if (context == null || context.length() <= 0){
			context = kettyHome + File.separatorChar + "webapps/ROOT";
		}else{
			context = kettyHome + File.separatorChar + "webapps" + File.separatorChar
					+ context;
		}

		System.setProperty("server.context", context);
		System.setProperty("ketty.home", kettyHome);
		System.setProperty("server.app", app);
				
		List<URL> urls = new ArrayList<URL>();
		addLibary(urls,kettyHome + File.separatorChar 
				+ "apps" + File.separatorChar + app);
		
		addLibary(urls,kettyHome + File.separatorChar + "lib");
		
		if (urls.size() <= 0){
			System.out.println("Can not find any libary jar.");
		}
		
		ClassLoader parent = Thread.currentThread().getContextClassLoader();
		if (parent == null){
			 parent = Start.class.getClassLoader();
		}
		if (parent == null){
			parent = ClassLoader.getSystemClassLoader();
		}
		URLClassLoader cl = new URLClassLoader(urls.toArray(new URL[urls.size()]),
				parent);			
		Thread.currentThread().setContextClassLoader(cl);
		
		String serverClass = gets("com.ketty.main.ConfigurableServer","KETTY_CLASS");
		try {
			@SuppressWarnings("unchecked")
			Class<? extends KettyServer> theClass = (Class<? extends KettyServer>) cl.loadClass(serverClass);
			KettyServer server = theClass.newInstance();
			server.start(new String[0]);
			server.join();
		}catch (Exception ex){
			ex.printStackTrace();
		}
		return ;
	}

}
