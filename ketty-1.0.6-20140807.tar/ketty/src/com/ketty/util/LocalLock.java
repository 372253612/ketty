package com.ketty.util;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.anysoft.util.Properties;

public class LocalLock implements Lock {
	protected static Logger logger = LogManager.getLogger(LocalLock.class);
	protected String lockFile;
	public LocalLock(String _lockName,Properties props){
		lockFile = _lockName;
	}
	
	@Override
	public void lock() {
		tryLock(0,TimeUnit.MILLISECONDS);
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {
		lock();
	}

	@Override
	public Condition newCondition() {
		return null;
	}

	@Override
	public boolean tryLock() {
		return lockFile(lockFile);
	}

	@Override
	public boolean tryLock(long timeout, TimeUnit timeUnit){
		logger.info("Using " + LocalLock.class.getName() + " to lock.");
		if (tryLock()){
			logger.info("Got the lock..");
			return true;
		}
		while (!tryLock()){
			try {
				logger.info("Can not get the lock . Waiting ....");
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				return false;
			}
		}
		logger.info("Got the lock..");
		return true;
	}

	@Override
	public void unlock() {
		logger.info("Release the lock.");
		unlockFile(lockFile);
	}

	public static boolean lockFile(String fileName){
		File file = new File(fileName);
		if (file.exists()){
			//文件已经存在,不在掌控中
			return false;
		}
		try {
			logger.info("The lock file is " + file.getAbsolutePath());
			return file.createNewFile();
		} catch (IOException e) {
			return false;
		}
	}
	
	public static boolean unlockFile(String fileName){
		File file = new File(fileName);
		if (!file.exists()){
			//这种情况,按道理不存在
			return false;
		}
		return file.delete();
	}
}
